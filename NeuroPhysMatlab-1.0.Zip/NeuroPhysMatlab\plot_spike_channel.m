clear;
load('/Users/Mee/Desktop/Plx to Matlab Converter/.\xue.mat')

% For Xue's data, spike 1-4 are real, other channels are spurious 
% analysis


i=2 % For channel 2:
y=SpikeData{i+1,7};
m=size(y)
m1=m(1,1)  % Number of spikes found
m2=m(1,2)  % Number of data points for each spikes 


x1=(1:1:m2); %number of spike waveform data points
y1=transpose(SpikeData{i+1,7}(1:m1,:));
figure;
plot(y1);set(gca,'FontSize',16)%;ylim([-2 2])







