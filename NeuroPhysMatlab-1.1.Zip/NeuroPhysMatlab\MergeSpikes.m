%% 
% This is the path to the ANY-maze data, which you may want to edit:

anyMazeDir = fullfile('C:', getenv('HOMEPATH'), '\OneDrive\Documents\ANY-maze')

%% 
% It's unlikely you need to edit anything below this line.
%% 
% 
% 
% This script merges spike data from a NeuroPhys data file and an ANY-maze data 
% file from the same time range. When it runs, 
%% 
% # In the first dialog window that appears select the NeuroPhys plx file (which 
% should be in your home directory in OneDrive\Documents\NeuroPhysData)
% # There is now a prompt int he Command Window, click that window and hit ENTER
% # In the next dialog window select the ANY-maze experiment you want to merge 
% with.
%% 
% The result is that there will be a variable named Combined structured as follows:
% 
% >> Combined.Properties.DimensionNames
% 
% ans =
% 
% 1�2 cell array
% 
% {'Time_1'}    {'Variables'}
% 
% >> Combined.Properties.VariableNames
% 
% ans =
% 
% 1�22 cell array
% 
% Columns 1 through 9
% 
% {'Spike1'}    {'Spike2'}    {'Spike3'}    {'Spike4'}    {'Spike5'}    {'Spike6'}    
% {'Spike7'}    {'Spike8'}    {'Spike9'}
% 
% Columns 10 through 17
% 
% {'Spike10'}    {'Spike11'}    {'Spike12'}    {'Spike13'}    {'Spike14'}    
% {'Spike15'}    {'Spike16'}    {'Time'}
% 
% Columns 18 through 22
% 
% {'PauseOn'}    {'PauseOff'}    {'TestEnd'}    {'CentrePositionX'}    {'CentrePositionY'}
% 
% >>length(Combined.Time_1)
% 
% ans =
% 
% 2856    % This value will be different depending on the length of your experiment
% 
% >> Combined.Time_1(1)
% 
% ans = 
% 
% datetime
% 
% 2020-02-12 09:43:07.341518   % Timestamp for the first row of data
% 
% >> Combined{1, 'Spike1'}
% 
% ans =
% 
% Columns 1 through 21
% 
% NaN   NaN   NaN   NaN  ...    % There's no spike in channel 1 at this timestamp 
% 
% >>   Combined{1,'Spike2'}
% 
% ans =
% 
% 1.0e-04 *
% 
% Columns 1 through 13
% 
% 0.0702    0.1129    0.1495    0.1587 ...  
% 
% % In channel 2 there is a spike at this timestamp with 35 
% 
% % data points, with voltages 7.02uV, 11.29uV, and so on.
% 
% % Sampling frequency for these data points is in the variable SpikeSamplingFreqHz
% 
% >> SpikeSamplingFreqHz
% 
% SpikeSamplingFreqHz =
% 
% _<samples per scond>_
% 
% >> spike1data = not(isnan(Combined.Spike1));  
% 
% % Boolean array of which rows have 
% 
% % spike data for Spike1
% 
% >> spike1data(1)
% 
% ans =
% 
% logical
% 
% 0   % This means that there is no data for Spike1 in row 1
% 
% 

convert_plx2mat;
%% 
% Get the corresponding data file from ANY-maze. The anyMazeDir can be edited 
% here to point to the right directory.

AT = getAnyMazeTimetable(anyMazeDir);

%% 
% Get initial time

Comment
matches = regexp(Comment, '^.*(\d\d\d\d-.*)', 'tokens');
startTime = datenum(matches{1});
sprintf('%.12f', startTime)
%% 
% Examine variables

header = SpikeData(1,:);
j = 0;
for i = 1:length(header)
    if strcmp(header(i), 'Unit 1')
        j = j + 1;
    end
    if startsWith(header(i), 'Unit')
        header(i) = strcat(header(i), char(64 + j));
    end
end
sd = cell2table(SpikeData(2:end,:), ...
    "VariableNames", header, ...
    "RowNames", SpikeData(2:end, 1));
%% 
% sd is now a table with columns ['Name', 'Timestamps unsorted', ... 'Waveforms 
% unsorted', ...]
% 
% and row names ['Spike1', 'Spike2', ...]
% 
% We now create a timetable with all the data.

TT = 0;
sampleInterval = 1./SpikeSamplingFreqHz;
for i = 1:length(sd.Name)
    name = sd.Name{i};
    times = sd{name, "Timestamps unsorted"}{1,1};
    waves = sd{name, "Waveforms unsorted"}{1,1};
    newtable = timetable( ...
        arrayfun( ...
           @(timestamp) datetime( ...
              startTime + (timestamp / 86400.000), ...
              "ConvertFrom", "datenum"), ...
           times), ...
           waves, ...
           'VariableNames', {name});
    if  istimetable(TT)
        TT = synchronize(TT, newtable);
    else
        TT = newtable;
    end
end
datetime.setDefaultFormats('default','yyyy-MM-dd hh:mm:ss.SSSSSS')

%% 
% Combine the spike timetable with the ANY-maze timetable.

Combined = synchronize(TT, AT);
head(Combined)