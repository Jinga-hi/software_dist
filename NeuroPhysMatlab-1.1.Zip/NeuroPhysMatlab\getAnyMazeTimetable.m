function [anyMazeTimetable] = getAnyMazeTimetable(anyMazeDir)
%GETANYMAZETIMETABLE Summary of this function goes here
%   Detailed explanation goes here
anyMazePattern = fullfile(anyMazeDir, "*.csv")
anyMazeFileName = uigetfile(anyMazePattern, ...
    "Select Any-MAZE output file", ...
    '')
anyMazeFile = fullfile(anyMazeDir, anyMazeFileName)

% Find the XML file in the same directory, which should be all the filename up to the first ' - ' sequence, adding an xml extension.
m = regexp(anyMazeFile, '(.*) - .*(\d+).csv', 'tokens', 'once');
c = m(1);  % everything up to the last ' - '
anyMazeXmlFileName = strcat(c{1,1}, '.xml')
c = m(2);  % test number should be just before the '.csv' extension
anyMazeTestNumber = c{1,1}
% Extract the date for the specific test file that we're reading from the XML metadata.
try
    dom = xmlread(anyMazeXmlFileName);
catch ME
    error(ME.message)
end

exp = dom.getElementsByTagName('experiment');
exper = exp.item(0);
anim = exper.getElementsByTagName('animal');
%if anim.getLength() > 1
%    error("Only one animal supported, please contact us at info@jinga-hi.com")
%end
for a = 0:anim.getLength()-1 % Iterate through the animals
    animal = anim.item(a);
    tst = animal.getElementsByTagName('test');
    for i = 0:tst.getLength()-1  % Iterate through the tests
        t = tst.item(i);
        number = getXmlSubTagValue(t, 'number');
        if number == anyMazeTestNumber  % Matching test number
            date = t.getElementsByTagName('date').item(0);
            % Extract the day, month, and year
            day = floor(str2double(getXmlSubTagValue(date, 'day')));
            month = floor(str2double(getXmlSubTagValue(date, 'month')));
            year = floor(str2double(getXmlSubTagValue(date, 'year')));
        end
    end
end

% We'll now create a timetable from the Any-MAZE data.
A = readtable(anyMazeFile);
newTimeColumn = arrayfun(@(duration) anyMazeConvertTime(duration, day, month, year), A.Time);
anyMazeTimetable = table2timetable(A, 'RowTimes', newTimeColumn)
end

