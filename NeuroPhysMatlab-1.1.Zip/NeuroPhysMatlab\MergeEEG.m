%% *Merge Any-Maze and NeuroPhys EEG data files*
% _Requests the ANY-maze and NeuroPhys files to be merged, and produces a merged 
% CSV in the ANY-maze file directory. The output CSV contains a column 'FullTime' 
% (last column) which is the time of the format 'YYYY-mm-dd HH:MM:SS.FFF' to millisecond 
% precision. The EEG data columns are labeled 'LFP1' ... 'LFPN' where N is the 
% number of channels._
% 
% You may need to change these paths to point to the directories where you have 
% your ANY-maze and NeuroPhys output directoriesT

anyMazeDir = fullfile('C:', getenv('HOMEPATH'), '\OneDrive\Documents\ANY-maze')
neuroPhysDir = fullfile('C:', getenv('HOMEPATH'), '\OneDrive\Documents\NeuroPhysData')
%% 
% You probably won't need to edit anything below this line.
%% ANY-maze file
% First, we create a dialog to allow you to select the ANY-maze data file that 
% you would like to merge:


AT = getAnyMazeTimetable(anyMazeDir)
%% NeuroPhys file
% Next, we create a dialog to select the NeuroPhys data file:

neuroPhysPattern = fullfile(neuroPhysDir, "*.plx")
neuroPhysFileName = uigetfile(neuroPhysPattern, ...
    "Select NeuroPhys output file", ...
    '')
neuroPhysFile = fullfile(neuroPhysDir, neuroPhysFileName)
%% 
% Read the NeuroPhys data file using plx2mat

[num_chans, continuous_channel_IDs] = plx_ad_chanmap(neuroPhysFile)
%% 
% Get the file metadata, including the datetime of the start of capture. The 
% 'Comment' field contains an ISO timestamp, so convert it to a Matlab timestamp.

[OpenedFileName, Version, Freq, Comment, Trodalness, NPW, PreTresh, SpikePeakV, SpikeADResBits, SlowPeakV, SlowADResBits, Duration, DateTime] = plx_information(neuroPhysFile)
matches = regexp(Comment, '^.*(\d\d\d\d-.*)', 'tokens')
startTime = datenum(matches{1})
sprintf('%.12f', startTime)
%% 
% GIven the list of timestamps at the beginning of each fragment, generate the 
% time values across all the samples in the fragments.

% Get samples for the first channel 
[continuous_sample_freq, total_num_datapoints, timestamps, fragment_lengths, raw_ad_values] = plx_ad(neuroPhysFile, continuous_channel_IDs(1));
chan = continuous_channel_IDs(1)
fprintf("Channel %d: Frequency %d points %d\n", ...
    chan, continuous_sample_freq, total_num_datapoints)

% Create an array the length of all samples
time_values = datetime.empty(length(raw_ad_values), 0);
%time_values = strings(length(raw_ad_values),1);
index = 1;
for y = 1:length(timestamps)
    % Within each fragment
    len = fragment_lengths(y);
    %fprintf("Converting fragment %d of length %d\n", y, len)
    ts = 0:(len-1);
    % Calculate the offsets from the beginning of capture
    timeOffset = timestamps(y) + ts'/continuous_sample_freq;
    % Add the offset to the start time from the Comment field, in days
    % (MATLAB serial date numbers are floating point days)
    absoluteTime = startTime + (timeOffset / 86400.0);  % MATLAB's Fraction of day    
    % Convert each serial date number to a string of form 'HH:MM:SS.SSS' to
    % match ANY-maze timestamps.
    time_values(index + ts) = arrayfun(@(serial) datetime(serial,"ConvertFrom", "datenum"), absoluteTime);
    %time_values(index + ts) = arrayfun(@(serial) datestr(serial, 'HH:MM:SS.FFF'), absoluteTime,"UniformOutput",false)
    index = index + len;
end
%% 
% Construct a timetable of all the channels of continuous samples

% Get the channel text names
% get text channel names
[n2, continuous_channames] = plx_adchan_names(neuroPhysFile);
continuous_channnames = deblank(cellstr(continuous_channames));

% Start the array with the data from the first channel:
all_channels = zeros(length(raw_ad_values), 32);
all_channels(:, 1) = raw_ad_values; % Capture channel 1 data

highestChan = 0;
for x = 2:num_chans
    chan = continuous_channel_IDs(x);
    [continuous_sample_freq, total_num_datapoints, timestamps, fragment_lengths, raw_ad_values] = plx_ad(neuroPhysFile, chan);
    if continuous_sample_freq > 0 && total_num_datapoints > 0
        highestChan = chan;
        fprintf("Channel %d: Frequency %d points %d\n", ...
            chan, continuous_sample_freq, total_num_datapoints)
        all_channels(:, x) = raw_ad_values;
    end
end
TT = array2timetable(all_channels(:,1:highestChan), 'RowTimes', time_values, 'VariableNames', continuous_channnames(1:highestChan));
fprintf("Highest channel populated: %d", highestChan)
%% 
% Now we merge he two timetables into one, filtering to just the time range 
% of the ANY-maze experiment trial

% Filter to just the neural data from the same time frame
S = timerange(min(AT.Time_1), max(AT.Time_1))
% Join the full ANY-maze daa with the relevant NeuroPhys data
joined = synchronize(AT, TT(S, :));
joined.FullTime = arrayfun(@(dateval) datestr(dateval, "YYYY-mm-dd HH:MM:SS.FFF"), joined.Time_1, "UniformOutput", false);
display(joined)
writetimetable(joined, fullfile(anyMazeDir, strcat(anyMazeFileName, '-withneuro.csv')))