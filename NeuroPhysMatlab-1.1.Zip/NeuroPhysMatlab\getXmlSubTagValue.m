function [out] = getXmlSubTagValue(tag, name)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
out = tag.getElementsByTagName(name).item(0).getTextContent;
end

