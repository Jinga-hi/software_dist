#!env python

import argparse
import io
import socket
import sys
import pylsl

from packet import Packet

class JagaLslCapture:
  """Receive data from a JAGA device and publish to Lab Streaming Layer

  LSL Python package location must be added to the PYTHONPATH before running this script.
  """
  def __init__(self, bind_port=55000):
    self.sock = None
    self.open_socket_(bind_port)
    self.label = str(bind_port % 55000)  # Numberic label indicating which device this is.
    self.channels = 16                   # Need a default until we've read the first packet.
    self.packets_per_second = 0
    self.fh = io.BytesIO()  # To convert packets to byte stream.
    self.outlet = None      # Will be populated with the StreamOutlet object.
    self.length = 1500      # Default read length, until we know the actual value.

  def open_socket_(self, bind_port):
    self.sock = socket.socket(type=socket.SOCK_DGRAM)
    self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    self.sock.bind(('0.0.0.0', bind_port))
    sys.stderr.write('Listening to port {}\n'.format(bind_port))

  def first_packet_(self):
    # Iterate through packet, ignoring possible CRC packets to get to the first data packet.
    # Extract metadata, and initialize the StreamOutlet.
    crc = True
    while crc:
      (data, address) = self.sock.recvfrom(self.length)  # Grab the first packet.
      self.length = len(data)
      self.fh.write(data)  # Append the received payload to the IO stream.
      self.fh.seek(0)      # Seek the beginning of the stream.
      sys.stderr.write('Receiving data. First packet length {}\n'.format(self.length))
      #(host, port) = socket.getnameinfo(address, socket.AI_NUMERICHOST)
      p = Packet(self.fh, channels=self.channels, has_timestamp=False)
      crc = p.crc
      self.channels = p.channels
    # Initialize the StreamInfo based on the metadata in the first data packet.
    if p.samples_per_second == 1000:
      type_label = 'EEG'
    else:
      type_label = 'Ephys'
    info = pylsl.StreamInfo(
            name='Jaga', type=type_label, channel_count=p.channels,
            nominal_srate=p.samples_per_second,
            channel_format=pylsl.cf_int32, source_id=self.label)
    sys.stderr.write('Writing to stream \'Jaga\', type \'{}\', source ID \'{}\'\n'
                     .format(type_label, self.label))
    sys.stderr.write('Channels: {}, Sampling rate: {}Hz\n'.format(
            p.channels, p.samples_per_second))
    # Open the stream.
    self.outlet = pylsl.StreamOutlet(info)
    self.packets_received = 1
    self.send_packet_to_outlet_(p, self.outlet)
    self.packets_per_second = int(p.samples_per_second / p.samples_per_packet)
    sys.stderr.write('Packets/second rate: {}\n'.format(self.packets_per_second))

  def send_packet_to_outlet_(self, packet, outlet):
    for sample in packet.all_samples:
      outlet.push_sample(sample)

  def start(self):
    """Start capturing data on the bound port, and feed to the Lab Streaming Layer PubSub.
    """
    self.first_packet_()  # Use first data packet to initialize parameters.
    self.channels = 16
    self.fh = io.BytesIO()
    sys.stderr.write('Samples received:\n')

    while True:
      (data, address) = self.sock.recvfrom(self.length)
      self.fh.write(data)
      self.fh.seek(0)
      p = Packet(self.fh, channels=self.channels, has_timestamp=False)
      if p.crc:
        # Ignore CRC packets
        continue
      self.packets_received += 1
      if self.packets_received % self.packets_per_second == 0:
        sys.stderr.write('{}\n'.format(self.packets_received * p.samples_per_packet))
      self.send_packet_to_outlet_(p, self.outlet)

  def __del__(self):
    self.sock.close()
    self.outlet.close()

if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  parser.add_argument('--bind_port', type=int, help='Port to listen to for data.',
                      default=55000)
  args = parser.parse_args()
  lsl = JagaLslCapture(args.bind_port)
  lsl.start()



