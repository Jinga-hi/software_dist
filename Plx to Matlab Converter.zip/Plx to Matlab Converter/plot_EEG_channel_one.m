
clear;
load('/Users/Mee/Desktop/Plx to Matlab Converter/.\eye_closed.mat')
%load('/Users/Mee/Desktop/Plx to Matlab Converter/.\eye_open.mat')



ns=16 % number of channel
m0=size(ContinuousData{2,4})
m=m0(1:1)

i=1;

     x=ContinuousData{i+1,3}(1:m,:);  %time values
     y=ContinuousData{i+1,4}(1:m,:);  %voltage values
     figure;
     plot(x,y);set(gca,'FontSize',16)%;ylim([-3.5 3.5])



%plot(x1,Yq);set(gca,'FontSize',16);ylim([-2 2])

% plot FFTs

samples=y;
Fs=1000;
NFFT = 2^nextpow2(m);  % Revised our original value; 
% generate x-axis for FFT plots
f = Fs/2*linspace(0,1,NFFT/2+1);
columns=1;
rows=1;
chan=i;
FL=0.1;
FH=50;

    % Calculate FFT after removing the DC offset
    Y = fft(samples - mean(samples),NFFT);
    figure;
    subplot(columns, rows, chan)
    plot(f,2*abs(Y(1:NFFT/2+1)));
    xlim([FL FH])
    ylim([0 0.1])
    title(['Chan ' num2str(chan)]);
    xlabel('Hz');
    ylabel('|Y(f)|'); 

