
clear All;
%load('/Users/Mee/Desktop/Mat/.\jd_1342_raw.mat')
load('.\jd_1342_raw.mat')

n=16 % number of channel, but only channel 1 and 13 are useful. 
m=size(ContinuousData{2,4}) % All data size
m=500; % only plot first number of data points if you don't want to use all data points.
range1=-0.2
range2=0.2

m1=500
m2=1000

i=2;
     x=ContinuousData{i+1,3}(m1:m2,:);  %time values
     y=ContinuousData{i+1,4}(m1:m2,:)  %voltage values
     
     
i=13;
     x1=ContinuousData{i+1,3}(m1:m2,:);  %time values
     y1=ContinuousData{i+1,4}(m1:m2,:) %voltage values
     
     plot(x,y,'b',x,y1,'r');ylim([range1 range2]);xlim([0.55 1]);set(gca,'FontSize',18)
     ;ylabel('Voltage Output (mV)');xlabel('Time (Sec)')



%plot(x1,Yq);set(gca,'FontSize',16);ylim([-2 2]);xlim([0.5 1])




