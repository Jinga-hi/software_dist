
% plot_jaga_penny_16EEG.m
% Copyright 2016 Jinga-hi, Inc.
% v.1.1

% 16 channel EEG.LFP CH1 (2 bytes) | CH2 (2 bytes) | CH3 (2 bytes) | CH4 (2
% bytes) ....

% The data is encoded big-endian, so each sample is MSB | LSB.

clear;

infile='/Users/Mee/Desktop/penny_ch1.data';
fid0 = fopen(infile, 'r');
samples=fread(fid0,'uint16','ieee-be');

nchans=16;
Fs=1000;
columns=4;
rows=4;
FL=10;
FH=200;

% plot time-series

hFig = figure;
set(hFig, 'Position', [200 1000 700 700])

for i=1:nchans    
    subplot(columns, rows, i)
    data = samples(i:nchans:end);
    
    plot((1:length(data)), data); 
    title(['Chan ' num2str(i)]);
    %axis([xmin xmax ymin ymax])    
end


figure;

% plot FFTs
L = numel(samples)/nchans;
NFFT = 2^nextpow2(L);  % Shehrzad's version: 19872; 
% generate x-axis for FFT plots
f = Fs/2*linspace(0,1,NFFT/2+1);

for chan=1:nchans
    % Calculate FFT after removing the DC offset
    Y = fft(double(samples(chan:nchans:end) - mean(samples(chan:nchans:end))),NFFT);
    subplot(columns, rows, chan)
    plot(f,2*abs(Y(1:NFFT/2+1)));
    xlim([FL FH])
    title(['Chan ' num2str(chan)]);
    xlabel('Hz');
    ylabel('|Y(f)|'); 
end